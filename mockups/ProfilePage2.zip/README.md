
  # Profile page design

  This is a code bundle for Profile page design. The original project is available at https://www.figma.com/design/B5AhAIxpAtnRrkQKGFD4LF/Profile-page-design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  