import { useState } from 'react';
import {
  Sun,
  Moon,
  Star,
  ChevronRight,
  User,
  Settings,
  Shield,
  Bell,
  CreditCard,
  LogOut
} from 'lucide-react';
import '../styles/animations.css';

export default function App() {
  const [isDark, setIsDark] = useState(true);
  const [activeSection, setActiveSection] = useState('overview');
  const [streamingServices, setStreamingServices] = useState([
    { name: 'Netflix', enabled: true, color: '#E50914' },
    { name: 'Hulu', enabled: true, color: '#1CE783' },
    { name: 'Disney+', enabled: false, color: '#113CCF' },
    { name: 'Max', enabled: true, color: '#0F2EF1' },
    { name: 'Prime Video', enabled: true, color: '#00A8E1' },
    { name: 'Apple TV+', enabled: false, color: '#000000' },
    { name: 'Paramount+', enabled: true, color: '#0064FF' },
    { name: 'Peacock', enabled: false, color: '#000000' },
    { name: 'Fubo', enabled: false, color: '#FF6B35' },
    { name: 'Tubi', enabled: true, color: '#FF6B00' },
    { name: 'Showtime', enabled: false, color: '#D81F27' },
    { name: 'Starz', enabled: false, color: '#000000' },
    { name: 'AMC+', enabled: true, color: '#0068A5' },
    { name: 'Discovery+', enabled: false, color: '#0066CC' },
    { name: 'ESPN+', enabled: true, color: '#CF0A2C' },
    { name: 'Pluto TV', enabled: false, color: '#F58220' }
  ]);

  const recentlyWatched = [
    { title: 'The Matrix', year: '1999', rating: 4.5 },
    { title: 'Inception', year: '2010', rating: 5.0 },
    { title: 'Interstellar', year: '2014', rating: 4.8 },
    { title: 'Dune', year: '2021', rating: 4.3 },
    { title: 'Oppenheimer', year: '2023', rating: 4.9 },
    { title: 'Blade Runner 2049', year: '2017', rating: 4.6 }
  ];

  const toggleService = (index: number) => {
    setStreamingServices(prev =>
      prev.map((service, i) =>
        i === index ? { ...service, enabled: !service.enabled } : service
      )
    );
  };

  const bgColor = isDark ? '#111115' : '#F4F4F6';
  const surfaceColor = isDark ? '#1C1C22' : '#FFFFFF';
  const textPrimary = isDark ? '#FFFFFF' : '#000000';
  const textSecondary = isDark ? '#9CA3AF' : '#6B7280';
  const accentRed = '#EE4242';

  return (
    <div
      className="w-[1440px] h-[900px] flex relative overflow-hidden"
      style={{ backgroundColor: bgColor }}
    >
      <div
        className="absolute inset-0 pointer-events-none opacity-30"
        style={{
          backgroundImage: `
            linear-gradient(0deg, transparent 24%, ${accentRed}15 25%, ${accentRed}15 26%, transparent 27%, transparent 74%, ${accentRed}15 75%, ${accentRed}15 76%, transparent 77%, transparent),
            linear-gradient(90deg, transparent 24%, ${accentRed}15 25%, ${accentRed}15 26%, transparent 27%, transparent 74%, ${accentRed}15 75%, ${accentRed}15 76%, transparent 77%, transparent)
          `,
          backgroundSize: '50px 50px'
        }}
      />
      {/* Corner Accent Lights */}
      <div
        className="absolute top-0 left-0 w-32 h-32 pointer-events-none"
        style={{
          background: `radial-gradient(circle at top left, ${accentRed}40 0%, transparent 70%)`,
          filter: 'blur(20px)'
        }}
      />
      <div
        className="absolute top-0 right-0 w-32 h-32 pointer-events-none"
        style={{
          background: `radial-gradient(circle at top right, ${accentRed}40 0%, transparent 70%)`,
          filter: 'blur(20px)'
        }}
      />
      <div
        className="absolute bottom-0 left-0 w-32 h-32 pointer-events-none"
        style={{
          background: `radial-gradient(circle at bottom left, ${accentRed}40 0%, transparent 70%)`,
          filter: 'blur(20px)'
        }}
      />
      <div
        className="absolute bottom-0 right-0 w-32 h-32 pointer-events-none"
        style={{
          background: `radial-gradient(circle at bottom right, ${accentRed}40 0%, transparent 70%)`,
          filter: 'blur(20px)'
        }}
      />
      {/* Animated Scanline */}
      <div
        className="scanline-effect absolute left-0 right-0 h-[100px] pointer-events-none opacity-20"
        style={{
          background: `linear-gradient(180deg, transparent 0%, ${accentRed}60 50%, transparent 100%)`,
          filter: 'blur(10px)'
        }}
      />
      {/* Left Sidebar */}
      <div
        className="w-[280px] h-full flex flex-col relative"
        style={{
          backgroundColor: surfaceColor,
          borderRight: `1px solid ${accentRed}40`,
          boxShadow: `0 0 30px ${accentRed}20`
        }}
      >
        <div
          className="absolute top-0 bottom-0 right-0 w-[2px]"
          style={{
            background: `linear-gradient(180deg, transparent 0%, ${accentRed} 50%, transparent 100%)`,
            boxShadow: `0 0 10px ${accentRed}`
          }}
        />
        {/* User Profile Section */}
        <div className="p-8 flex flex-col items-center relative border-b" style={{ borderColor: isDark ? '#2A2A32' : '#E5E7EB' }}>
          <div
            className="absolute bottom-0 left-0 right-0 h-[1px]"
            style={{
              background: `linear-gradient(90deg, transparent 0%, ${accentRed} 50%, transparent 100%)`,
              boxShadow: `0 0 8px ${accentRed}`
            }}
          />
          <div
            className="w-20 h-20 rounded-full flex items-center justify-center mb-4 relative"
            style={{
              backgroundColor: accentRed,
              boxShadow: `0 0 30px ${accentRed}, 0 0 60px ${accentRed}80, inset 0 0 20px ${accentRed}40`
            }}
          >
            <span className="text-2xl font-bold text-white relative z-10">JD</span>
            <div
              className="absolute inset-0 rounded-full animate-pulse"
              style={{
                background: `radial-gradient(circle at center, ${accentRed}00 0%, ${accentRed}40 100%)`,
                filter: 'blur(8px)'
              }}
            />
          </div>
          <h2 className="text-lg font-semibold mb-1 relative z-10" style={{ color: textPrimary }}>
            John Doe
          </h2>
          <p className="text-sm relative z-10" style={{ color: textSecondary }}>
            john.doe@email.com
          </p>
        </div>

        {/* Profile Navigation */}
        <nav className="flex-1 py-6 px-4">
          <ProfileNavItem
            icon={User}
            label="Profile Overview"
            active={activeSection === 'overview'}
            onClick={() => setActiveSection('overview')}
            isDark={isDark}
            accentRed={accentRed}
            textPrimary={textPrimary}
            textSecondary={textSecondary}
          />
          <ProfileNavItem
            icon={Settings}
            label="Account Settings"
            active={activeSection === 'settings'}
            onClick={() => setActiveSection('settings')}
            isDark={isDark}
            accentRed={accentRed}
            textPrimary={textPrimary}
            textSecondary={textSecondary}
          />
          <ProfileNavItem
            icon={Shield}
            label="Privacy & Security"
            active={activeSection === 'privacy'}
            onClick={() => setActiveSection('privacy')}
            isDark={isDark}
            accentRed={accentRed}
            textPrimary={textPrimary}
            textSecondary={textSecondary}
          />
          <ProfileNavItem
            icon={Bell}
            label="Notifications"
            active={activeSection === 'notifications'}
            onClick={() => setActiveSection('notifications')}
            isDark={isDark}
            accentRed={accentRed}
            textPrimary={textPrimary}
            textSecondary={textSecondary}
          />
          <ProfileNavItem
            icon={CreditCard}
            label="Subscription"
            active={activeSection === 'subscription'}
            onClick={() => setActiveSection('subscription')}
            isDark={isDark}
            accentRed={accentRed}
            textPrimary={textPrimary}
            textSecondary={textSecondary}
          />
        </nav>

        {/* Sign Out Button */}
        <div className="p-4">
          <button
            className="w-full py-3 px-4 rounded-lg flex items-center justify-center gap-2 font-medium text-white relative overflow-hidden group"
            style={{
              backgroundColor: accentRed,
              boxShadow: `0 0 20px ${accentRed}40`
            }}
          >
            <div
              className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity"
              style={{
                background: `linear-gradient(90deg, transparent 0%, ${accentRed}60 50%, transparent 100%)`,
                boxShadow: `inset 0 0 20px ${accentRed}80`
              }}
            />
            <LogOut size={20} className="relative z-10" />
            <span className="relative z-10">Sign Out</span>
          </button>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 overflow-y-auto relative">
        <div
          className="absolute top-0 left-0 right-0 h-[1px]"
          style={{
            background: `linear-gradient(90deg, transparent 0%, ${accentRed}60 50%, transparent 100%)`,
            boxShadow: `0 0 10px ${accentRed}`
          }}
        />
        {/* Header with Theme Toggle */}
        <div className="p-8 flex justify-end">
          <button
            onClick={() => setIsDark(!isDark)}
            className="p-3 rounded-lg relative group"
            style={{
              backgroundColor: surfaceColor,
              border: `1px solid ${accentRed}30`,
              boxShadow: `0 0 15px ${accentRed}30`
            }}
          >
            <div
              className="absolute inset-0 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity"
              style={{
                background: `radial-gradient(circle at center, ${accentRed}30 0%, transparent 70%)`,
                boxShadow: `inset 0 0 20px ${accentRed}40`
              }}
            />
            {isDark ? (
              <Sun
                size={20}
                color={accentRed}
                className="relative z-10"
                style={{ filter: `drop-shadow(0 0 4px ${accentRed})` }}
              />
            ) : (
              <Moon
                size={20}
                color={accentRed}
                className="relative z-10"
                style={{ filter: `drop-shadow(0 0 4px ${accentRed})` }}
              />
            )}
          </button>
        </div>

        <div className="px-8 pb-8">
          {activeSection === 'overview' && (
            <>
              {/* Stats Row */}
              <div className="grid grid-cols-3 gap-6 mb-10">
                <StatCard title="Watched" count="247" isDark={isDark} surfaceColor={surfaceColor} textPrimary={textPrimary} textSecondary={textSecondary} accentRed={accentRed} />
                <StatCard title="Watchlist" count="89" isDark={isDark} surfaceColor={surfaceColor} textPrimary={textPrimary} textSecondary={textSecondary} accentRed={accentRed} />
                <StatCard title="Reviews" count="42" isDark={isDark} surfaceColor={surfaceColor} textPrimary={textPrimary} textSecondary={textSecondary} accentRed={accentRed} />
              </div>

              {/* Streaming Services */}
              <div className="mb-10">
                <h3 className="text-xl font-semibold mb-6" style={{ color: textPrimary }}>
                  Streaming Services
                </h3>
                <div
                  className="p-6 rounded-lg relative overflow-hidden"
                  style={{
                    backgroundColor: surfaceColor,
                    border: `1px solid ${accentRed}30`,
                    boxShadow: `0 0 20px ${accentRed}20, inset 0 0 30px ${accentRed}10`
                  }}
                >
                  <div
                    className="absolute top-0 left-0 right-0 h-[2px]"
                    style={{
                      background: `linear-gradient(90deg, transparent 0%, ${accentRed} 50%, transparent 100%)`,
                      boxShadow: `0 0 10px ${accentRed}`
                    }}
                  />
                  <div className="flex flex-wrap gap-4 relative z-10">
                    {streamingServices.map((service, index) => (
                      <div
                        key={service.name}
                        className="flex items-center gap-3 px-4 py-3 rounded-lg border relative"
                        style={{
                          borderColor: service.enabled ? `${accentRed}60` : (isDark ? '#2A2A32' : '#E5E7EB'),
                          backgroundColor: isDark ? '#111115' : '#F9FAFB',
                          boxShadow: service.enabled ? `0 0 15px ${accentRed}40, inset 0 0 15px ${accentRed}20` : 'none'
                        }}
                      >
                        <div
                          className="w-3 h-3 rounded-full relative"
                          style={{
                            backgroundColor: service.enabled ? service.color : textSecondary,
                            boxShadow: service.enabled ? `0 0 10px ${service.color}, 0 0 20px ${service.color}80` : 'none'
                          }}
                        />
                        <span className="text-sm font-medium" style={{ color: textPrimary }}>
                          {service.name}
                        </span>
                        <button
                          onClick={() => toggleService(index)}
                          className="ml-2 relative inline-flex h-5 w-9 items-center rounded-full transition-colors"
                          style={{
                            backgroundColor: service.enabled ? accentRed : (isDark ? '#374151' : '#D1D5DB'),
                            boxShadow: service.enabled ? `0 0 10px ${accentRed}` : 'none'
                          }}
                        >
                          <span
                            className="inline-block h-4 w-4 transform rounded-full bg-white transition-transform"
                            style={{
                              transform: service.enabled ? 'translateX(18px)' : 'translateX(2px)',
                              boxShadow: service.enabled ? `0 0 8px ${accentRed}` : 'none'
                            }}
                          />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Recently Watched */}
              <div className="mb-10">
                <h3 className="text-xl font-semibold mb-6" style={{ color: textPrimary }}>
                  Recently Watched
                </h3>
                <div className="grid grid-cols-6 gap-4">
                  {recentlyWatched.map((movie) => (
                    <div key={movie.title} className="group cursor-pointer">
                      <div
                        className="aspect-[2/3] rounded-lg mb-3 flex items-center justify-center relative overflow-hidden transition-all"
                        style={{
                          backgroundColor: isDark ? '#2A2A32' : '#E5E7EB',
                          border: `1px solid ${accentRed}30`,
                          boxShadow: `0 0 15px ${accentRed}20`
                        }}
                      >
                        <div
                          className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity"
                          style={{
                            background: `linear-gradient(135deg, ${accentRed}20 0%, transparent 100%)`
                          }}
                        />
                        <span className="text-4xl relative z-10" style={{ color: textSecondary }}>🎬</span>
                        <div
                          className="absolute bottom-0 left-0 right-0 h-[2px]"
                          style={{
                            background: `linear-gradient(90deg, transparent 0%, ${accentRed} 50%, transparent 100%)`,
                            boxShadow: `0 0 10px ${accentRed}`
                          }}
                        />
                      </div>
                      <h4 className="font-medium mb-1 text-sm" style={{ color: textPrimary }}>
                        {movie.title}
                      </h4>
                      <p className="text-xs mb-2" style={{ color: textSecondary }}>
                        {movie.year}
                      </p>
                      <div className="flex items-center gap-1">
                        <Star
                          size={14}
                          fill={accentRed}
                          color={accentRed}
                          style={{ filter: `drop-shadow(0 0 4px ${accentRed})` }}
                        />
                        <span className="text-xs font-medium" style={{ color: textPrimary }}>
                          {movie.rating}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}

          {activeSection === 'settings' && (
            <div>
              <h2 className="text-3xl font-bold mb-8" style={{ color: textPrimary }}>
                Account Settings
              </h2>
              <div
                className="rounded-lg divide-y relative overflow-hidden mb-6"
                style={{
                  backgroundColor: surfaceColor,
                  divideColor: isDark ? '#2A2A32' : '#E5E7EB',
                  border: `1px solid ${accentRed}30`,
                  boxShadow: `0 0 20px ${accentRed}20, inset 0 0 30px ${accentRed}10`
                }}
              >
                <div
                  className="absolute top-0 left-0 right-0 h-[2px]"
                  style={{
                    background: `linear-gradient(90deg, transparent 0%, ${accentRed} 50%, transparent 100%)`,
                    boxShadow: `0 0 10px ${accentRed}`
                  }}
                />
                <SettingRow
                  label="Email"
                  value="john.doe@email.com"
                  isDark={isDark}
                  textPrimary={textPrimary}
                  textSecondary={textSecondary}
                  accentRed={accentRed}
                />
                <SettingRow
                  label="Username"
                  value="@johndoe247"
                  isDark={isDark}
                  textPrimary={textPrimary}
                  textSecondary={textSecondary}
                  accentRed={accentRed}
                />
                <SettingRow
                  label="Change Password"
                  value="••••••••"
                  isDark={isDark}
                  textPrimary={textPrimary}
                  textSecondary={textSecondary}
                  accentRed={accentRed}
                />
                <SettingRow
                  label="Phone Number"
                  value="+1 (555) 123-4567"
                  isDark={isDark}
                  textPrimary={textPrimary}
                  textSecondary={textSecondary}
                  accentRed={accentRed}
                />
                <SettingRow
                  label="Language"
                  value="English (US)"
                  isDark={isDark}
                  textPrimary={textPrimary}
                  textSecondary={textSecondary}
                  accentRed={accentRed}
                />
                <SettingRow
                  label="Time Zone"
                  value="Pacific Time (PT)"
                  isDark={isDark}
                  textPrimary={textPrimary}
                  textSecondary={textSecondary}
                  accentRed={accentRed}
                />
              </div>
              <button
                className="py-3 px-6 rounded-lg font-medium text-white relative overflow-hidden group"
                style={{
                  backgroundColor: accentRed,
                  boxShadow: `0 0 20px ${accentRed}40`
                }}
              >
                <div
                  className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity"
                  style={{
                    background: `linear-gradient(90deg, transparent 0%, ${accentRed}60 50%, transparent 100%)`,
                    boxShadow: `inset 0 0 20px ${accentRed}80`
                  }}
                />
                <span className="relative z-10">Save Changes</span>
              </button>
            </div>
          )}

          {activeSection === 'privacy' && (
            <div>
              <h2 className="text-3xl font-bold mb-8" style={{ color: textPrimary }}>
                Privacy & Security
              </h2>
              <div
                className="rounded-lg divide-y relative overflow-hidden"
                style={{
                  backgroundColor: surfaceColor,
                  divideColor: isDark ? '#2A2A32' : '#E5E7EB',
                  border: `1px solid ${accentRed}30`,
                  boxShadow: `0 0 20px ${accentRed}20, inset 0 0 30px ${accentRed}10`
                }}
              >
                <div
                  className="absolute top-0 left-0 right-0 h-[2px]"
                  style={{
                    background: `linear-gradient(90deg, transparent 0%, ${accentRed} 50%, transparent 100%)`,
                    boxShadow: `0 0 10px ${accentRed}`
                  }}
                />
                <SettingRow
                  label="Profile Visibility"
                  value="Public"
                  isDark={isDark}
                  textPrimary={textPrimary}
                  textSecondary={textSecondary}
                  accentRed={accentRed}
                />
                <SettingRow
                  label="Activity Status"
                  value="Visible to Friends"
                  isDark={isDark}
                  textPrimary={textPrimary}
                  textSecondary={textSecondary}
                  accentRed={accentRed}
                />
                <SettingRow
                  label="Two-Factor Authentication"
                  value="Enabled"
                  isDark={isDark}
                  textPrimary={textPrimary}
                  textSecondary={textSecondary}
                  accentRed={accentRed}
                />
                <SettingRow
                  label="Connected Devices"
                  value="3 devices"
                  isDark={isDark}
                  textPrimary={textPrimary}
                  textSecondary={textSecondary}
                  accentRed={accentRed}
                />
                <SettingRow
                  label="Data Download"
                  value="Request your data"
                  isDark={isDark}
                  textPrimary={textPrimary}
                  textSecondary={textSecondary}
                  accentRed={accentRed}
                />
              </div>
            </div>
          )}

          {activeSection === 'notifications' && (
            <div>
              <h2 className="text-3xl font-bold mb-8" style={{ color: textPrimary }}>
                Notifications
              </h2>
              <div
                className="rounded-lg divide-y relative overflow-hidden"
                style={{
                  backgroundColor: surfaceColor,
                  divideColor: isDark ? '#2A2A32' : '#E5E7EB',
                  border: `1px solid ${accentRed}30`,
                  boxShadow: `0 0 20px ${accentRed}20, inset 0 0 30px ${accentRed}10`
                }}
              >
                <div
                  className="absolute top-0 left-0 right-0 h-[2px]"
                  style={{
                    background: `linear-gradient(90deg, transparent 0%, ${accentRed} 50%, transparent 100%)`,
                    boxShadow: `0 0 10px ${accentRed}`
                  }}
                />
                <SettingRow
                  label="Email Notifications"
                  value="Enabled"
                  isDark={isDark}
                  textPrimary={textPrimary}
                  textSecondary={textSecondary}
                  accentRed={accentRed}
                />
                <SettingRow
                  label="Push Notifications"
                  value="Enabled"
                  isDark={isDark}
                  textPrimary={textPrimary}
                  textSecondary={textSecondary}
                  accentRed={accentRed}
                />
                <SettingRow
                  label="New Releases"
                  value="Weekly digest"
                  isDark={isDark}
                  textPrimary={textPrimary}
                  textSecondary={textSecondary}
                  accentRed={accentRed}
                />
                <SettingRow
                  label="Friend Activity"
                  value="Enabled"
                  isDark={isDark}
                  textPrimary={textPrimary}
                  textSecondary={textSecondary}
                  accentRed={accentRed}
                />
                <SettingRow
                  label="Recommendations"
                  value="Daily"
                  isDark={isDark}
                  textPrimary={textPrimary}
                  textSecondary={textSecondary}
                  accentRed={accentRed}
                />
              </div>
            </div>
          )}

          {activeSection === 'subscription' && (
            <div>
              <h2 className="text-3xl font-bold mb-8" style={{ color: textPrimary }}>
                Subscription
              </h2>
              <div
                className="rounded-lg p-8 relative overflow-hidden mb-6"
                style={{
                  backgroundColor: surfaceColor,
                  border: `1px solid ${accentRed}30`,
                  boxShadow: `0 0 20px ${accentRed}20, inset 0 0 30px ${accentRed}10`
                }}
              >
                <div
                  className="absolute top-0 left-0 right-0 h-[2px]"
                  style={{
                    background: `linear-gradient(90deg, transparent 0%, ${accentRed} 50%, transparent 100%)`,
                    boxShadow: `0 0 10px ${accentRed}`
                  }}
                />
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h3 className="text-2xl font-bold mb-2" style={{ color: accentRed }}>
                      Premium Plan
                    </h3>
                    <p style={{ color: textSecondary }}>
                      Unlimited access to all features
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-3xl font-bold" style={{ color: textPrimary }}>
                      $9.99
                    </p>
                    <p className="text-sm" style={{ color: textSecondary }}>
                      per month
                    </p>
                  </div>
                </div>
                <div className="space-y-3 mb-6">
                  <div className="flex items-center gap-2">
                    <div
                      className="w-2 h-2 rounded-full"
                      style={{
                        backgroundColor: accentRed,
                        boxShadow: `0 0 8px ${accentRed}`
                      }}
                    />
                    <p style={{ color: textPrimary }}>Unlimited movie tracking</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <div
                      className="w-2 h-2 rounded-full"
                      style={{
                        backgroundColor: accentRed,
                        boxShadow: `0 0 8px ${accentRed}`
                      }}
                    />
                    <p style={{ color: textPrimary }}>Advanced recommendations</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <div
                      className="w-2 h-2 rounded-full"
                      style={{
                        backgroundColor: accentRed,
                        boxShadow: `0 0 8px ${accentRed}`
                      }}
                    />
                    <p style={{ color: textPrimary }}>Ad-free experience</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <div
                      className="w-2 h-2 rounded-full"
                      style={{
                        backgroundColor: accentRed,
                        boxShadow: `0 0 8px ${accentRed}`
                      }}
                    />
                    <p style={{ color: textPrimary }}>Early access to new features</p>
                  </div>
                </div>
                <p className="text-sm" style={{ color: textSecondary }}>
                  Next billing date: May 1, 2026
                </p>
              </div>
              <div
                className="rounded-lg divide-y relative overflow-hidden"
                style={{
                  backgroundColor: surfaceColor,
                  divideColor: isDark ? '#2A2A32' : '#E5E7EB',
                  border: `1px solid ${accentRed}30`,
                  boxShadow: `0 0 20px ${accentRed}20, inset 0 0 30px ${accentRed}10`
                }}
              >
                <div
                  className="absolute top-0 left-0 right-0 h-[2px]"
                  style={{
                    background: `linear-gradient(90deg, transparent 0%, ${accentRed} 50%, transparent 100%)`,
                    boxShadow: `0 0 10px ${accentRed}`
                  }}
                />
                <SettingRow
                  label="Payment Method"
                  value="Visa •••• 4242"
                  isDark={isDark}
                  textPrimary={textPrimary}
                  textSecondary={textSecondary}
                  accentRed={accentRed}
                />
                <SettingRow
                  label="Billing History"
                  value="View all invoices"
                  isDark={isDark}
                  textPrimary={textPrimary}
                  textSecondary={textSecondary}
                  accentRed={accentRed}
                />
                <SettingRow
                  label="Cancel Subscription"
                  value="Manage subscription"
                  isDark={isDark}
                  textPrimary={textPrimary}
                  textSecondary={textSecondary}
                  accentRed={accentRed}
                />
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

interface ProfileNavItemProps {
  icon: React.ElementType;
  label: string;
  active: boolean;
  onClick: () => void;
  isDark: boolean;
  accentRed: string;
  textPrimary: string;
  textSecondary: string;
}

function ProfileNavItem({ icon: Icon, label, active, onClick, isDark, accentRed, textPrimary, textSecondary }: ProfileNavItemProps) {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <button
      onClick={onClick}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className="w-full flex items-center gap-3 px-4 py-3 rounded-lg mb-2 transition-all relative overflow-hidden"
      style={{
        backgroundColor: active ? (isDark ? '#2A2A32' : '#FEF2F2') : 'transparent',
        border: active ? `1px solid ${accentRed}40` : '1px solid transparent',
        boxShadow: active ? `0 0 15px ${accentRed}30, inset 0 0 15px ${accentRed}20` : 'none'
      }}
    >
      <div
        className="absolute left-0 top-0 bottom-0 w-[2px] transition-all"
        style={{
          backgroundColor: accentRed,
          boxShadow: (active || isHovered) ? `0 0 10px ${accentRed}` : 'none',
          opacity: (active || isHovered) ? 1 : 0
        }}
      />
      <Icon
        size={20}
        color={active ? accentRed : textSecondary}
        className="relative z-10"
        style={{
          filter: (active || isHovered) ? `drop-shadow(0 0 4px ${accentRed})` : 'none',
          transition: 'all 0.2s'
        }}
      />
      <span
        className="font-medium relative z-10 transition-colors"
        style={{ color: active ? accentRed : textPrimary }}
      >
        {label}
      </span>
    </button>
  );
}

interface StatCardProps {
  title: string;
  count: string;
  isDark: boolean;
  surfaceColor: string;
  textPrimary: string;
  textSecondary: string;
  accentRed: string;
}

function StatCard({ title, count, isDark, surfaceColor, textPrimary, textSecondary, accentRed }: StatCardProps) {
  return (
    <div
      className="p-6 rounded-lg relative overflow-hidden"
      style={{
        backgroundColor: surfaceColor,
        border: `1px solid ${accentRed}30`,
        boxShadow: `0 0 20px ${accentRed}20, inset 0 0 30px ${accentRed}10`
      }}
    >
      <div
        className="absolute top-0 left-0 right-0 h-[2px]"
        style={{
          background: `linear-gradient(90deg, transparent 0%, ${accentRed} 50%, transparent 100%)`,
          boxShadow: `0 0 10px ${accentRed}`
        }}
      />
      <p className="text-sm mb-2 relative z-10" style={{ color: textSecondary }}>
        {title}
      </p>
      <p className="text-4xl font-bold relative z-10" style={{ color: textPrimary }}>
        {count}
      </p>
    </div>
  );
}

interface SettingRowProps {
  label: string;
  value: string;
  isDark: boolean;
  textPrimary: string;
  textSecondary: string;
  accentRed: string;
}

function SettingRow({ label, value, isDark, textPrimary, textSecondary, accentRed }: SettingRowProps) {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div
      className="flex items-center justify-between p-6 cursor-pointer transition-all relative z-10"
      style={{
        backgroundColor: isHovered ? `${accentRed}10` : 'transparent'
      }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div
        className="absolute left-0 top-0 bottom-0 w-[2px] transition-all"
        style={{
          backgroundColor: accentRed,
          boxShadow: isHovered ? `0 0 10px ${accentRed}, 0 0 20px ${accentRed}80` : 'none',
          opacity: isHovered ? 1 : 0
        }}
      />
      <div className="relative z-10">
        <p className="font-medium mb-1" style={{ color: textPrimary }}>
          {label}
        </p>
        <p className="text-sm" style={{ color: textSecondary }}>
          {value}
        </p>
      </div>
      <ChevronRight
        size={20}
        color={isHovered ? accentRed : textSecondary}
        style={{
          filter: isHovered ? `drop-shadow(0 0 4px ${accentRed})` : 'none',
          transition: 'all 0.2s'
        }}
      />
    </div>
  );
}
